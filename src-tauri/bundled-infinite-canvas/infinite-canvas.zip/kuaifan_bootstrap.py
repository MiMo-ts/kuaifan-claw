# -*- coding: utf-8 -*-
import json, os, sys
from pathlib import Path
BASE = Path(__file__).resolve().parent
HOME = Path(os.environ.get('INFINITE_CANVAS_HOME', BASE / 'module-home')).resolve()
DATA = Path(os.environ.get('INFINITE_CANVAS_DATA', HOME / 'data')).resolve()
ASSETS = Path(os.environ.get('INFINITE_CANVAS_ASSETS', HOME / 'assets')).resolve()
API_ENV = Path(os.environ.get('INFINITE_CANVAS_API_ENV', HOME / 'API' / '.env')).resolve()
PROVIDERS = Path(os.environ.get('API_PROVIDERS_FILE', HOME / 'config' / 'api_providers.json')).resolve()
ROUTES = Path(os.environ.get('INFINITE_CANVAS_ROUTES_FILE', HOME / 'config' / 'model_routes.json')).resolve()
PORT = int(os.environ.get('INFINITE_CANVAS_PORT') or os.environ.get('PORT') or '18300')
for path in [HOME, DATA, DATA/'canvases', DATA/'conversations', DATA/'media_previews', ASSETS, ASSETS/'input', ASSETS/'output', ASSETS/'library', ASSETS/'uploads', HOME/'config', HOME/'API', HOME/'logs']:
    path.mkdir(parents=True, exist_ok=True)
if API_ENV.is_file():
    for raw in API_ENV.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, val = line.split('=', 1)
        key = key.strip()
        val = val.strip().strip(chr(34)).strip(chr(39))
        if key and key not in os.environ:
            os.environ[key] = val
os.environ['API_PROVIDERS_FILE'] = str(PROVIDERS)
os.environ['INFINITE_CANVAS_HOME'] = str(HOME)
os.environ['INFINITE_CANVAS_DATA'] = str(DATA)
os.environ['INFINITE_CANVAS_ASSETS'] = str(ASSETS)
os.environ['INFINITE_CANVAS_ROUTES_FILE'] = str(ROUTES)
os.environ['INFINITE_CANVAS_PORT'] = str(PORT)
os.environ['PORT'] = str(PORT)
os.chdir(BASE)
sys.path.insert(0, str(BASE))
import main as app_main
app_main.BASE_DIR = str(BASE)
app_main.DATA_DIR = str(DATA)
app_main.CONVERSATION_DIR = str(DATA / 'conversations')
app_main.CANVAS_DIR = str(DATA / 'canvases')
app_main.MEDIA_PREVIEW_DIR = str(DATA / 'media_previews')
app_main.ASSET_LIBRARY_PATH = str(DATA / 'asset_library.json')
app_main.PROMPT_LIBRARY_PATH = str(DATA / 'prompt_libraries.json')
app_main.API_PROVIDERS_FILE = str(PROVIDERS)
app_main.RUNNINGHUB_WORKFLOW_STORE_FILE = str(DATA / 'runninghub_workflows.json')
app_main.SHARED_FOLDERS_FILE = str(DATA / 'shared_folders.json')
app_main.STORAGE_SETTINGS_FILE = str(DATA / 'storage_settings.json')
app_main.PROJECTS_PATH = str(DATA / 'projects.json')
app_main.API_ENV_FILE = str(API_ENV)
app_main.GLOBAL_CONFIG_FILE = str(HOME / 'config' / 'global_config.json')
app_main.ASSETS_DIR = str(ASSETS)
app_main.OUTPUT_INPUT_DIR = str(ASSETS / 'input')
app_main.OUTPUT_OUTPUT_DIR = str(ASSETS / 'output')
app_main.ASSET_LIBRARY_DIR = str(ASSETS / 'library')
app_main.LOCAL_UPLOAD_DIR = str(ASSETS / 'uploads')
app_main.OUTPUT_DIR = str(ASSETS / 'output')

# StaticFiles 在 main 导入时已挂到 runtime 默认目录；这里 ASSETS/DATA 已切到 modules 目录，
# 必须重新挂载，否则 /assets/* /output/* 预览放大会空白。
def remount_static_dirs():
    try:
        from fastapi.staticfiles import StaticFiles
        routes = getattr(app_main.app, 'routes', None)
        if routes is not None:
            keep = []
            for route in list(routes):
                path = getattr(route, 'path', None)
                if path in ('/static', '/output', '/assets'):
                    continue
                keep.append(route)
            app_main.app.router.routes = keep
        app_main.app.mount('/static', StaticFiles(directory=str(Path(app_main.STATIC_DIR))), name='static')
        app_main.app.mount('/output', StaticFiles(directory=str(ASSETS / 'output')), name='output')
        app_main.app.mount('/assets', StaticFiles(directory=str(ASSETS)), name='assets')
        print('[kuaifanclaw] remounted /assets ->', ASSETS)
        print('[kuaifanclaw] remounted /output ->', ASSETS / 'output')
    except Exception as exc:
        print('[kuaifanclaw] remount static failed:', exc)
remount_static_dirs()
def _load_json(path, default):
    try:
        if path.is_file():
            return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        print('[kuaifanclaw] load failed', path, exc)
    return default
def _providers():
    raw = _load_json(PROVIDERS, [])
    return raw if isinstance(raw, list) else []
def _routes():
    raw = _load_json(ROUTES, {})
    return raw if isinstance(raw, dict) else {}
def _provider_by_id(provider_id):
    pid = str(provider_id or '').strip()
    for item in _providers():
        if str(item.get('id') or '') == pid:
            return item
    primary = next((p for p in _providers() if p.get('primary')), None)
    return primary or (_providers()[0] if _providers() else {})
def resolve_model_route(capability='chat', provider_id='', model=''):
    capability = str(capability or 'chat').strip().lower()
    routes = _routes()
    default_route = dict(routes.get(capability) or {})
    provider = _provider_by_id(provider_id or default_route.get('provider') or '')
    pid = str(provider.get('id') or default_route.get('provider') or '')
    model_name = str(model or default_route.get('model') or '').strip()
    if not model_name:
        key = {'chat':'chat_models','image':'image_models','video':'video_models'}.get(capability, 'chat_models')
        models = provider.get(key) or []
        model_name = str((models or [''])[0] or '')
    protocols = provider.get('model_protocols') or {}
    request_modes = provider.get('model_request_modes') or {}
    protocol = str(protocols.get(model_name) or provider.get('protocol') or default_route.get('protocol') or 'openai')
    if capability == 'image':
        request_mode = str(request_modes.get(model_name) or provider.get('image_request_mode') or default_route.get('request_mode') or 'openai')
    elif capability == 'video':
        request_mode = str(request_modes.get(model_name) or provider.get('video_request_mode') or default_route.get('request_mode') or 'openai-video-proxy')
    else:
        request_mode = 'chat_completions'
    return {
        'capability': capability,
        'provider': pid,
        'model': model_name,
        'protocol': protocol,
        'request_mode': request_mode,
        'base_url': str(provider.get('base_url') or default_route.get('base_url') or ''),
        'api_key': str(provider.get('api_key') or ''),
        'route': default_route,
        'video_models': (provider.get('video_models') or default_route.get('models') or [])[:],
        'image_models': provider.get('image_models') or [],
        'chat_models': provider.get('chat_models') or [],
    }
app_main.resolve_model_route = resolve_model_route
_orig_get_api_provider = getattr(app_main, 'get_api_provider', None)
def get_api_provider_shared(provider_id='comfly'):
    provider = _provider_by_id(provider_id)
    if provider:
        return provider
    if callable(_orig_get_api_provider):
        return _orig_get_api_provider(provider_id)
    return {'id': provider_id or 'kuaifan', 'protocol': 'openai', 'base_url': '', 'api_key': '', 'chat_models': [], 'image_models': [], 'video_models': []}
app_main.get_api_provider = get_api_provider_shared
from fastapi import HTTPException
@app_main.app.get('/api/kuaifan/model-routes')
async def kuaifan_model_routes():
    providers = []
    for item in _providers():
        providers.append({
            'id': item.get('id'),
            'name': item.get('name'),
            'protocol': item.get('protocol'),
            'enabled': item.get('enabled', True),
            'primary': item.get('primary', False),
            'chat_models': item.get('chat_models') or [],
            'image_models': item.get('image_models') or [],
            'video_models': item.get('video_models') or [],
            'image_size_options': item.get('image_size_options') or ['auto','1k','2k','4k'],
            'image_ratio_options': item.get('image_ratio_options') or ['square','portrait','landscape','wide','story'],
            'video_resolution_options': item.get('video_resolution_options') or ['','480p','720p','1080p'],
            'video_aspect_options': item.get('video_aspect_options') or ['16:9','9:16','1:1'],
            'has_key': bool(item.get('api_key')),
        })
    return {'routes': _routes(), 'providers': providers, 'defaults': {'chat': resolve_model_route('chat'), 'image': resolve_model_route('image'), 'video': resolve_model_route('video')}}
@app_main.app.post('/api/kuaifan/resolve-route')
async def kuaifan_resolve_route(payload: dict):
    capability = str((payload or {}).get('capability') or 'chat')
    provider_id = str((payload or {}).get('provider_id') or (payload or {}).get('provider') or '')
    model = str((payload or {}).get('model') or '')
    route = resolve_model_route(capability, provider_id, model)
    key = route.get('api_key') or ''
    route['has_key'] = bool(key)
    route['api_key_preview'] = (('*' * max(0, len(key)-4)) + key[-4:]) if key else ''
    route.pop('api_key', None)
    return route
_orig_generate_ai_image = getattr(app_main, 'generate_ai_image', None)
if callable(_orig_generate_ai_image):
    async def generate_ai_image_shared(*args, **kwargs):
        """Compat wrapper: accept any call signature from main.py callers."""
        prompt = kwargs.get('prompt', args[0] if len(args) > 0 else '')
        size = kwargs.get('size', args[1] if len(args) > 1 else '')
        quality = kwargs.get('quality', args[2] if len(args) > 2 else '')
        model = kwargs.get('model', args[3] if len(args) > 3 else '')
        reference_images = kwargs.get('reference_images', args[4] if len(args) > 4 else None)
        provider_id = kwargs.get('provider_id', args[5] if len(args) > 5 else 'comfly')
        aspect_ratio = kwargs.get('aspect_ratio', args[6] if len(args) > 6 else '')
        resolution = kwargs.get('resolution', args[7] if len(args) > 7 else '')
        watermark = kwargs.get('watermark', args[8] if len(args) > 8 else False)
        route = resolve_model_route('image', provider_id, model)
        provider_id = route.get('provider') or provider_id
        model = route.get('model') or model
        if not route.get('api_key'):
            raise HTTPException(status_code=400, detail='Missing image API key. Save provider key in KuaiFan model settings first.')
        call_kwargs = dict(kwargs)
        call_kwargs.update({
            'prompt': prompt, 'size': size, 'quality': quality, 'model': model,
            'reference_images': reference_images, 'provider_id': provider_id,
            'aspect_ratio': aspect_ratio, 'resolution': resolution, 'watermark': watermark,
        })
        try:
            return await _orig_generate_ai_image(**call_kwargs)
        except TypeError:
            pass
        try:
            return await _orig_generate_ai_image(prompt, size, quality, model, reference_images, provider_id, aspect_ratio, resolution, watermark)
        except TypeError:
            pass
        try:
            return await _orig_generate_ai_image(prompt, size, quality, model, reference_images, provider_id, aspect_ratio, resolution)
        except TypeError:
            return await _orig_generate_ai_image(prompt, size, quality, model, reference_images, provider_id)
    app_main.generate_ai_image = generate_ai_image_shared
if hasattr(app_main, 'canvas_video'):
    _orig_canvas_video = app_main.canvas_video
    async def canvas_video_shared(payload):
        route = resolve_model_route('video', getattr(payload, 'provider_id', ''), getattr(payload, 'model', ''))
        if not route.get('api_key'):
            raise HTTPException(status_code=400, detail='Missing video API key. Save provider key in KuaiFan model settings first.')
        if not getattr(payload, 'provider_id', None):
            payload.provider_id = route.get('provider')
        if not getattr(payload, 'model', None):
            payload.model = route.get('model')
        return await _orig_canvas_video(payload)
    app_main.canvas_video = canvas_video_shared
try:
    import re as _re
    def _provider_key_env(provider_id):
        pid = str(provider_id or '').strip().lower()
        if pid == 'comfly':
            return 'COMFLY_API_KEY'
        if pid == 'modelscope':
            return 'MODELSCOPE_API_KEY'
        if pid == 'runninghub':
            return 'RUNNINGHUB_API_KEY'
        if pid == 'volcengine':
            return 'ARK_API_KEY'
        return 'API_PROVIDER_' + _re.sub(r'[^A-Za-z0-9]', '_', pid).upper() + '_KEY'
    def _provider_api_key(provider):
        if not isinstance(provider, dict):
            return ''
        key = str(provider.get('api_key') or '').strip()
        if key:
            return key
        pid = str(provider.get('id') or '').strip()
        env_name = _provider_key_env(pid)
        return str(os.environ.get(env_name) or os.environ.get('API_KEY') or os.environ.get('OPENAI_API_KEY') or '').strip()
    providers = _providers()
    for item in providers:
        key = _provider_api_key(item)
        pid = str(item.get('id') or '').strip()
        if key and pid:
            os.environ[_provider_key_env(pid)] = key
            item['api_key'] = key
    primary = next((p for p in providers if p.get('primary')), None) or (providers[0] if providers else {})
    if primary:
        primary_key = _provider_api_key(primary)
        if primary_key:
            app_main.AI_API_KEY = primary_key
            os.environ['API_KEY'] = primary_key
            os.environ['OPENAI_API_KEY'] = primary_key
            os.environ[_provider_key_env(primary.get('id'))] = primary_key
        if primary.get('base_url'):
            app_main.AI_BASE_URL = primary.get('base_url')
            os.environ['OPENAI_BASE_URL'] = str(primary.get('base_url'))
        if primary.get('chat_models'):
            app_main.CHAT_MODELS = list(primary.get('chat_models') or [])
            app_main.CHAT_MODEL = app_main.CHAT_MODELS[0]
        if primary.get('image_models'):
            app_main.IMAGE_MODELS = list(primary.get('image_models') or [])
            if app_main.IMAGE_MODELS:
                app_main.IMAGE_MODEL = app_main.IMAGE_MODELS[0]
        if primary.get('video_models'):
            app_main.VIDEO_MODELS = list(primary.get('video_models') or [])
    _orig_provider_env_key_value = getattr(app_main, 'provider_env_key_value', None)
    def provider_env_key_value_shared(provider_id):
        pid = str(provider_id or '').strip().lower()
        for item in _providers():
            if str(item.get('id') or '').strip().lower() == pid:
                key = _provider_api_key(item)
                if key:
                    return key
        if callable(_orig_provider_env_key_value):
            return _orig_provider_env_key_value(provider_id)
        return str(os.environ.get(_provider_key_env(pid)) or '').strip()
    app_main.provider_env_key_value = provider_env_key_value_shared
    _orig_public_provider = getattr(app_main, 'public_provider', None)
    if callable(_orig_public_provider):
        def public_provider_shared(provider):
            item = dict(provider or {})
            key = _provider_api_key(item)
            if key:
                item['api_key'] = key
            public = _orig_public_provider(item)
            if isinstance(public, dict):
                public['has_key'] = bool(key or public.get('has_key'))
                if key and not public.get('key_preview'):
                    public['key_preview'] = ('*' * max(0, len(key)-4)) + key[-4:]
            return public
        app_main.public_provider = public_provider_shared
except Exception as exc:
    print('[kuaifanclaw] hydrate shared models failed', exc)
import uvicorn
uvicorn.run(app_main.app, host='127.0.0.1', port=PORT, ws_ping_interval=None, ws_ping_timeout=None)
