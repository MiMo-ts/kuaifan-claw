# Changelog

## 0.2.0

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.9

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.7-beta.1

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.7-beta.0

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.6

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.5-fix.2

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.5

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.4

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.1

### Changes

- Version alignment with core Clawdbot release numbers.

## 0.1.0

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.2.2

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.31-beta.1

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.31-beta.0

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.23

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.22

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.21

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.20

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.17-1

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.17

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.16

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.15

### Changes

- Version alignment with core Clawdbot release numbers.

## 2026.1.14

### Features

- Version alignment with core Clawdbot release numbers.
- Matrix channel plugin with homeserver + user ID auth (access token or password login with device name).
- Direct messages with pairing/allowlist/open/disabled policies and allowFrom support.
- Group/room controls: allowlist policy, per-room config, mention gating, auto-reply, per-room skills/system prompts.
- Threads: replyToMode controls and thread replies (off/inbound/always).
- Messaging: text chunking, media uploads with size caps, reactions, polls, typing, and message edits/deletes.
- Actions: read messages, list/remove reactions, pin/unpin/list pins, member info, room info.
- Auto-join invites with allowlist support.
- Status + probe reporting for health checks.
