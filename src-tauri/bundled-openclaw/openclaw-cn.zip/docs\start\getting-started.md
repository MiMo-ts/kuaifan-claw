---
summary: "安装 OpenClaw 并在几分钟内运行您的第一次聊天。"
read_when:
  - 从零开始首次设置
  - 您想要最快的工作聊天路径
title: "入门指南"
---

# 入门指南

目标：从零开始，用最少的设置运行第一次工作聊天。

<Info>
最快聊天：打开控制 UI（无需频道设置）。运行 `openclaw-cn dashboard`
并在浏览器中聊天，或在
<Tooltip headline="网关主机" tip="运行 OpenClaw 网关服务的机器。">网关主机</Tooltip>上打开 `http://127.0.0.1:18789/`。
文档：[仪表板](/web/dashboard) 和 [控制 UI](/web/control-ui)。
</Info>

## 前提条件

- Node 22 或更新版本

<Tip>
如果不确定，请使用 `node --version` 检查您的 Node 版本。
</Tip>

## 快速设置（CLI）

### 1. 安装 OpenClaw（推荐）

**macOS/Linux：**

```bash
curl -fsSL https://clawd.org.cn/install.sh | bash
```

**Windows (PowerShell)：**

```powershell
iwr -useb https://clawd.org.cn/install.ps1 | iex
```

> **注意：** 其他安装方法和要求：[安装](/install)。

### 2. 运行引导向导

```bash
openclaw-cn onboard --install-daemon
```

向导配置认证、网关设置和可选频道。
详情请参见 [引导向导](/start/wizard)。

### 3. 检查网关

如果您安装了服务，它应该已经在运行：

```bash
openclaw-cn gateway status
```

### 4. 打开控制 UI

```bash
openclaw-cn dashboard
```

> **✓** 如果控制 UI 加载成功，您的网关已准备就绪。

## 可选检查和附加功能

#### 在前台运行网关

适用于快速测试或故障排除。

```bash
openclaw-cn gateway --port 18789
```

#### 发送测试消息

需要配置的频道。

```bash
openclaw-cn message send --target +15555550123 --message "来自 OpenClaw 的问候"
```

## 有用的环境变量

如果您将 OpenClaw 作为服务账户运行或想要自定义配置/状态位置：

- `OPENCLAW_HOME` 设置用于内部路径解析的主目录。
- `OPENCLAW_STATE_DIR` 覆盖状态目录。
- `OPENCLAW_CONFIG_PATH` 覆盖配置文件路径。

完整的环境变量参考：[环境变量](/help/environment)。

## 深入了解

<Columns>
  <Card title="引导向导（详细信息）" href="/start/wizard">
    完整的 CLI 向导参考和高级选项。
  </Card>
  <Card title="macOS 应用引导" href="/start/onboarding">
    macOS 应用的首次运行流程。
  </Card>
</Columns>

## 您将拥有

- 正在运行的网关
- 已配置的认证
- 控制 UI 访问权限或已连接的频道

## 下一步

- 私信安全和审批：[配对](/channels/pairing)
- 连接更多频道：[频道](/channels)
- 高级工作流和源码安装：[设置](/start/setup)
