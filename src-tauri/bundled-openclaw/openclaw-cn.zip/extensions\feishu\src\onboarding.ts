import type {
  ChannelOnboardingAdapter,
  OpenClawConfig as ClawdbotConfig,
} from "openclaw/plugin-sdk";

/** Feishu domain: "feishu" (China) or "lark" (International). */
type FeishuDomain = "feishu" | "lark";
import {
  listFeishuAccountIds,
  resolveDefaultFeishuAccountId,
  resolveFeishuAccount,
  promptAccountId,
  normalizeAccountId,
  DEFAULT_ACCOUNT_ID,
} from "openclaw/plugin-sdk";

export const feishuOnboardingAdapter: ChannelOnboardingAdapter = {
  channel: "feishu",
  getStatus: async ({ cfg }) => {
    const configured = listFeishuAccountIds(cfg).some((id) => {
      const acc = resolveFeishuAccount({ cfg, accountId: id });
      return Boolean(acc.config.appId && acc.config.appSecret);
    });
    return {
      channel: "feishu",
      configured,
      statusLines: [`Feishu: ${configured ? "configured" : "needs credentials"}`],
      selectionHint: configured ? "recommended · configured" : "requires Lark Open Platform app",
      quickstartScore: configured ? 1 : 10,
    };
  },
  configure: async ({ cfg, prompter, accountOverrides, shouldPromptAccountIds }) => {
    const override = accountOverrides.feishu?.trim();
    const defaultId = resolveDefaultFeishuAccountId(cfg);
    let accountId = override ? normalizeAccountId(override) : defaultId;

    if (shouldPromptAccountIds && !override) {
      accountId = await promptAccountId({
        cfg,
        prompter,
        label: "Feishu",
        currentId: accountId,
        listAccountIds: listFeishuAccountIds,
        defaultAccountId: defaultId,
      });
    }

    let next = { ...cfg };
    const resolved = resolveFeishuAccount({ cfg, accountId });
    const isDefault = accountId === DEFAULT_ACCOUNT_ID;

    // Check env vars for default account
    if (isDefault && process.env.FEISHU_APP_ID && process.env.FEISHU_APP_SECRET) {
      const useEnv = await prompter.confirm({
        message: "FEISHU_APP_ID/SECRET detected. Use env vars?",
        initialValue: true,
      });
      if (useEnv) {
        // Ensure section exists and is enabled
        next = updateFeishuConfig(next, accountId, { enabled: true });
        return { cfg: next, accountId };
      }
    }

    // Prompt for domain (Feishu China vs Lark International) first
    const currentDomain = resolved.config.domain ?? "feishu";
    const domain = (await prompter.select({
      message: "选择平台 / Select platform",
      options: [
        { value: "feishu", label: "飞书（国内版）", hint: "open.feishu.cn" },
        { value: "lark", label: "Lark（国际版）", hint: "open.larksuite.com" },
      ],
      initialValue: currentDomain,
    })) as FeishuDomain;

    const platformLabel = domain === "lark" ? "Lark" : "飞书";

    const existingAppId = resolved.config.appId ?? "";
    const appId = String(
      await prompter.text({
        message: `输入 ${platformLabel} App ID (cli_...)`,
        initialValue: existingAppId,
        validate: (val) => (val?.trim() ? undefined : "Required"),
      }),
    ).trim();

    const existingAppSecret = resolved.config.appSecret ?? "";
    const appSecret = String(
      await prompter.text({
        message: `输入 ${platformLabel} App Secret`,
        initialValue: existingAppSecret,
        validate: (val) => (val?.trim() ? undefined : "Required"),
      }),
    ).trim();

    next = updateFeishuConfig(next, accountId, { appId, appSecret, domain, enabled: true });

    return { cfg: next, accountId };
  },
  disable: (cfg) => {
    // Simple disable logic
    const next = { ...cfg };
    if (next.channels?.feishu) {
      // If we have specific accounts, we might need more complex logic,
      // but usually this disables the whole channel or default account.
      // For simplicity, let's just mark the structure if it exists.
      // But actually, the core might handle channel disabling if we don't return anything?
      // Telegram adapter sets enabled: false.
      // Let's do nothing for now or just return cfg if not implemented.
      // But better to implement basic disable.
      if (next.channels.feishu.accounts) {
        // Disable all accounts? Or just return modified config
      }
    }
    return next;
  },
};

function updateFeishuConfig(
  cfg: ClawdbotConfig,
  accountId: string,
  updates: { appId?: string; appSecret?: string; domain?: FeishuDomain; enabled?: boolean },
): ClawdbotConfig {
  const next = { ...cfg };
  const feishu = next.channels?.feishu || {};
  next.channels = { ...next.channels, feishu };

  if (accountId === DEFAULT_ACCOUNT_ID) {
    // Write top-level fields for compatibility with the official Feishu plugin
    // which reads appId/appSecret directly from channels.feishu (flat structure).
    if (updates.appId !== undefined) feishu.appId = updates.appId;
    if (updates.appSecret !== undefined) feishu.appSecret = updates.appSecret;
    if (updates.domain !== undefined) feishu.domain = updates.domain;
    if (updates.enabled !== undefined) feishu.enabled = updates.enabled;
    // Also write into accounts.default for our community plugin's nested reader.
    if (!feishu.accounts) feishu.accounts = {};
    const acc = feishu.accounts[accountId] || { appId: "", appSecret: "" };
    feishu.accounts[accountId] = {
      ...acc,
      ...updates,
    };
  } else {
    if (!feishu.accounts) feishu.accounts = {};
    const acc = feishu.accounts[accountId] || { appId: "", appSecret: "" };
    feishu.accounts[accountId] = {
      ...acc,
      ...updates,
    };
  }

  return next;
}
