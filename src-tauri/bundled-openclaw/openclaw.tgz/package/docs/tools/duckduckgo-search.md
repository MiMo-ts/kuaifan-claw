---
summary: "DuckDuckGo web search -- key-free provider (experimental, HTML-based)"
read_when:
  - You want a web search provider that requires no API key
  - You want to use DuckDuckGo for web_search
  - You want an explicitly selected key-free search provider
title: "DuckDuckGo search"
---

OpenClaw supports DuckDuckGo as a **key-free** `web_search` provider. No API
key or account is required.

<Warning>
  DuckDuckGo is an **experimental, unofficial** integration that pulls results
  from DuckDuckGo's non-JavaScript search pages - not an official API. Expect
  occasional breakage from bot-challenge pages or HTML changes.
</Warning>

## Setup

No API key needed - just set DuckDuckGo as your provider:

<Steps>
  <Step title="Configure">
    ```bash
    openclaw configure --section web
    # Select "duckduckgo" as the provider
    ```
  </Step>
</Steps>

## Config

```json5
{
  tools: {
    web: {
      search: {
        provider: "duckduckgo",
      },
    },
  },
}
```

Optional plugin-level settings for region and SafeSearch:

```json5
{
  plugins: {
    entries: {
      duckduckgo: {
        config: {
          webSearch: {
            region: "us-en", // DuckDuckGo region code
            safeSearch: "moderate", // "strict", "moderate", or "off"
          },
        },
      },
    },
  },
}
```

## Tool parameters

<ParamField path="query" type="string" required>
Search query.
</ParamField>

<ParamField path="count" type="number" default="5">
Results to return (1-10).
</ParamField>

<ParamField path="region" type="string">
DuckDuckGo region code (e.g. `us-en`, `uk-en`, `de-de`).
</ParamField>

<ParamField path="safeSearch" type="'strict' | 'moderate' | 'off'" default="moderate">
SafeSearch level.
</ParamField>

Region and SafeSearch can also be set in plugin config (see above) - tool
parameters override config values per-query.

## Notes

- **No API key** - works after you select DuckDuckGo as your `web_search`
  provider
- **Experimental** - gathers results from DuckDuckGo's non-JavaScript HTML
  search pages, not an official API or SDK
- **Bot-challenge risk** - DuckDuckGo may serve CAPTCHAs or block requests
  under heavy or automated use
- **HTML parsing** - results depend on page structure, which can change without
  notice
- **Explicit selection** - OpenClaw does not choose DuckDuckGo automatically
  when no API-backed provider is configured
- **SafeSearch defaults to moderate** when not configured

<Tip>
  For production use, consider [Brave Search](/tools/brave-search) (free tier
  available) or another API-backed provider.
</Tip>

## Related

- [Web Search overview](/tools/web) -- all providers and auto-detection
- [Brave Search](/tools/brave-search) -- structured results with free tier
- [Exa Search](/tools/exa-search) -- neural search with content extraction
